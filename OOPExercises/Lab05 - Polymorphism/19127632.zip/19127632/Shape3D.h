#pragma once
class Shape3D
{
public:
	virtual double volume() = 0;
};

