#include "Sphere.h"
#include <iostream>
int main()
{
	Sphere a(5);
	std::cout << a.volume();
	return 0;
}